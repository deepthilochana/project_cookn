package com.cookin.cookin.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CookinAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(CookinAppApplication.class, args);
	}

}
